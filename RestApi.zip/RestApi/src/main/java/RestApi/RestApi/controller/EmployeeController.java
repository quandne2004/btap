package RestApi.RestApi.controller;


import RestApi.RestApi.dto.EmployeeDto;
import RestApi.RestApi.service.employee.EmployeeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class EmployeeController {

    private final EmployeeService employeeService;

    @PostMapping("/employee")
    public ResponseEntity<?> postCar(@RequestBody EmployeeDto employeeDto) throws IOException {
        boolean success = employeeService.postEmployee(employeeDto);
        if (success){
            return ResponseEntity.status(HttpStatus.CREATED).build();
        }else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @GetMapping("/allEmployee")
    public ResponseEntity<?> getAllCar(){
        return ResponseEntity.ok(employeeService.getAllEmployee());
    }

    @DeleteMapping("/employees/{id}")
    public ResponseEntity<Void> deleteCar(@PathVariable Long id){
        employeeService.deleteEmployee(id);
        return ResponseEntity.noContent().build(); // Sử dụng noContent() để phản hồi mã 204 No Content
    }

    @GetMapping("/employee/{id}")
    public ResponseEntity<EmployeeDto> getCarById(@PathVariable Long id){
        EmployeeDto employeeDto = employeeService.getEmployeeById(id);
        return ResponseEntity.ok(employeeDto);
    }

    @PutMapping("/employee/{employeeId}")
    public ResponseEntity<Void> updateCar(@PathVariable Long employeeId, @RequestBody EmployeeDto employeeDto) throws IOException{
        try{
            boolean success = employeeService.updateEmployee(employeeId,employeeDto);
            if (success) return ResponseEntity.status(HttpStatus.OK).build();
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }
}
