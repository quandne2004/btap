package RestApi.RestApi.enums;

public enum UserRole {

    ADMIN,
    CUSTOMER
}
