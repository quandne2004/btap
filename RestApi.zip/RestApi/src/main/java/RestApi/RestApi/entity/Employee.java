package RestApi.RestApi.entity;


import RestApi.RestApi.dto.EmployeeDto;
import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "employees")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String firstName;
    private String lastName;
    private String phone;

    public EmployeeDto getEmployeeDto(){
        EmployeeDto employeeDto = new EmployeeDto();

        employeeDto.setId(id);
        employeeDto.setFirstName(firstName);
        employeeDto.setLastName(lastName);
        employeeDto.setPhone(phone);
        return employeeDto;
    }


}
