package RestApi.RestApi.service.employee;


import RestApi.RestApi.dto.EmployeeDto;
import RestApi.RestApi.entity.Employee;
import RestApi.RestApi.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class EmployeeServiceImpl implements EmployeeService{

    private final EmployeeRepository employeeRepository;



    public boolean postEmployee(EmployeeDto employeeDto){
        try{
            Employee employee = new Employee();
            employee.setFirstName(employeeDto.getFirstName());
            employee.setLastName(employeeDto.getLastName());
            employee.setPhone(employeeDto.getPhone());

            employeeRepository.save(employee);
            return true;
        }catch (Exception e){
            return false;
        }

    }

    public List<EmployeeDto> getAllEmployee(){
        return employeeRepository.findAll().stream().map(Employee::getEmployeeDto).collect(Collectors.toList());
    }

    public void deleteEmployee(Long id){
        employeeRepository.findById(id);
    }



    public EmployeeDto getEmployeeById(Long id) {
        Optional<Employee> employee = employeeRepository.findById(id);
        return employee.map(Employee::getEmployeeDto).orElse(null);
    }

    public boolean updateEmployee(Long employeeId, EmployeeDto employeeDto) {
        Optional<Employee> optional = employeeRepository.findById(employeeId);
        if (optional.isPresent()) {
            Employee existingEmployee = optional.get(); // Get the existing employee

            existingEmployee.setFirstName(employeeDto.getFirstName());
            existingEmployee.setLastName(employeeDto.getLastName());
            existingEmployee.setPhone(employeeDto.getPhone());

            employeeRepository.save(existingEmployee); // Save the updated employee
            return true;
        } else {
            return false;
        }
    }

}
