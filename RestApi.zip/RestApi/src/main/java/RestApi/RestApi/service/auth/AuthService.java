package RestApi.RestApi.service.auth;

import RestApi.RestApi.dto.SignupRequest;
import RestApi.RestApi.dto.UserDto;

public interface AuthService {
    UserDto createUser(SignupRequest signupRequest);

    boolean hasCustomerWithEmail(String email);

}
