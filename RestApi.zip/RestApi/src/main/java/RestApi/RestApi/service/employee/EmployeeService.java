package RestApi.RestApi.service.employee;

import RestApi.RestApi.dto.EmployeeDto;

import java.util.List;

public interface EmployeeService {

    boolean postEmployee(EmployeeDto employeeDto);
    List<EmployeeDto> getAllEmployee();
    void deleteEmployee(Long id);
    EmployeeDto getEmployeeById(Long id);
    boolean updateEmployee(Long employeeId,EmployeeDto employeeDto);
}
